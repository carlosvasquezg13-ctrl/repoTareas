
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question('¿Cuántos productos fabricó la empresa? ', (respuesta) => {
    let totalProductos = parseInt(respuesta);
    let contadorRevision = 0;

    for (let i = 1; i <= totalProductos; i++) {
        if (i % 3 === 0) {
            console.log(`Producto ${i}: Necesita revisión`);
            contadorRevision++;
        }
    }
    console.log(`Total de productos que deberán revisarse: ${contadorRevision}`);
    rl.close();
});


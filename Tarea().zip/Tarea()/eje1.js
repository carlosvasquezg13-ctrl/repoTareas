const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question('¿Cuántos boletos comprará? ', (respuesta) => {
    let boletos = parseInt(respuesta);

    for (let i = 1; i <= boletos; i++) {
        if (i >= 5) {
            console.log(`Boleto ${i}: Precio $3.00 (Tiene descuento de $1.00)`);
        } else {
            console.log(`Boleto ${i}: Precio $4.00`);
        }
    }
    rl.close();
});



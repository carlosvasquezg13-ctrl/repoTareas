
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question('¿Cuántos visitantes llegarán? ', (respuesta) => {
    let visitantes = parseInt(respuesta);
    let entradasGratuitas = 0;

    for (let i = 1; i <= visitantes; i++) {
        if (i % 5 === 0) {
            entradasGratuitas++;
        }
    }
    console.log(`Total de entradas gratuitas otorgadas: ${entradasGratuitas}`);
    rl.close();
});


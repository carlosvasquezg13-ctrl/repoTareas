import readline from "node:readline";
const rl=readline.createInterface({

    input:process.stdin,
    output:process.stdout

})
rl.question("Ingrese el nombre de el festejado",function(Nombre){
    rl.question("Ingrese el precio de la decoracion",function(decoracion){
        rl.question("Ingrese el precio de el pastel",function(pastel){
            rl.question("Ingrese el coste de la comida",function(comida){
                rl.question("Ingrese los costos por entretenimiento",function(entretenimiento){
                    decoracion=Number(decoracion)
                    pastel=Number(pastel)
                    comida=Number(comida)
                    entretenimiento=Number(entretenimiento)
                    const totalpag=(decoracion+pastel+comida+entretenimiento)
                    const totalpagDiv=(totalpag/2)
                    console.log(`El total a pagar por la fiesta es de:${totalpag}$\n Total dividido entre dos partes:${totalpagDiv}$`)
                    rl.close()
                })
            })
        }) 
    })
})
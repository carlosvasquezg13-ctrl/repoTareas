import readline from "node:readline";
const rl=readline.createInterface({

    input:process.stdin,
    output:process.stdout

})
rl.question("Ingrese su nombre",function(nombre){
    rl.question("Ingrese la cantidad de dias que trabajo durante el mes",function(dias){
        rl.question("Ingrese el gasto diario que tuvo en el desayuno",function(desayuno){
            rl.question("Ingrese el gasto diario que tuvo en el almuerzo",function(almuerzo){
                rl.question("Ingrese el gasto que tuvo en transporte ",function(transporte){
                    dias=Number(dias)
                    desayuno=Number(desayuno)
                    almuerzo=Number(almuerzo)
                    transporte=Number(transporte)
                    const GastoDia=(desayuno+almuerzo+transporte)
                    const GastoMes=(GastoDia*dias)
                    console.log(`Su gasto diario fue de:${GastoDia}$\n  Su gasto mensual fue de:${GastoMes}$`)
                    rl.close()
                })
            })
        })
    })
})